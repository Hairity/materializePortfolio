$(document).ready(function(){
  $('.parallax').parallax();
});
   

$(document).ready(function(){
  $('.carousel').carousel();
});

